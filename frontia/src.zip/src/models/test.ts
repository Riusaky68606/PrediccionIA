export class Test{
    constructor(
        public campo1:String,
        public campo2:Number,
        public campo3:Number
    ){}
}