export class Modelo{
    constructor(
        public rating:Number,
        public sector:String,
        public ownership:String,
        public job_title:String,
        public job_in_headquarters:Number,
        public job_seniority:String,
        public job_skills:String,
    ){}
}